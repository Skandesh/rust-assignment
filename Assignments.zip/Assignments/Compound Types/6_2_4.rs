
fn main() {
    // Fix the error
    let _arr = [1, 2, 3]; //array elements must be of the same type

    println!("Success!");
}
