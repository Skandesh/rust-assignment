
fn main() {
    // Fill the blank to print each char in "你好，世界"
    for c in "你好，世界".chars() { //converting these to characters and then looping over it
        println!("{}", c)
    }
}
