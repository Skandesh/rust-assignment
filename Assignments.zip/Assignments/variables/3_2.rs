
// Fill the blanks in the code to make it compile
fn main() {
    let mut x =  1;  //By default variables are immutable
    x += 2; 
    
    assert_eq!(x, 3);
    println!("Success!");
}
