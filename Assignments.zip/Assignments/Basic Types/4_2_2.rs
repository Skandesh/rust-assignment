
// Make it work
fn main() {
    let c1 = '中'; // to be enclosed within 'single quotes' to be treated as char
    print_char(c1.to);
} 

fn print_char(c : char) {
    println!("{}", c);
}
